/*import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, map } from 'rxjs';
import { Service } from '../../core/models/service';

@Injectable({ providedIn: 'root' })
export class ServicesData{
  private readonly _list$ = new BehaviorSubject<Service[]>([]);
  readonly list$ = this._list$.asObservable();

  constructor(private http: HttpClient) {
    this.load();
  }

  load() {
    this.http.get<Service[]>('/assets/services.json').subscribe(d => this._list$.next(d));
  }

  getById(id: number) {
    return this.list$.pipe(map(list => list.find(s => s.id === id)));
  }

  // Mock CRUD (solo front): actualiza BehaviorSubject
  create(item: Service) {
    const list = [...this._list$.value, item];
    this._list$.next(list);
  }
  update(item: Service) {
    const list = this._list$.value.map(s => (s.id === item.id ? item : s));
    this._list$.next(list);
  }
  remove(id: number) {
    this._list$.next(this._list$.value.filter(s => s.id !== id));
  }
}
*/
import { Injectable, inject, PLATFORM_ID } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { isPlatformBrowser } from '@angular/common';
import { BehaviorSubject, map } from 'rxjs';
import { Service } from '../models/service';

@Injectable({ providedIn: 'root' })
export class ServicesData {
  private http = inject(HttpClient);
  private platformId = inject(PLATFORM_ID);

  private readonly _list$ = new BehaviorSubject<Service[]>([]);
  readonly list$ = this._list$.asObservable();

  constructor() {
    // Evita que SSR haga la petición
    if (isPlatformBrowser(this.platformId)) {
      this.load();
    }
  }

  load() {
    this.http.get<Service[]>('/assets/services.json')
      .subscribe((d: Service[]) => this._list$.next(d));
  }

  getById(id: number) {
    return this.list$.pipe(map(list => list.find(s => s.id === id)));
  }

  create(item: Service) { this._list$.next([...this._list$.value, item]); }
  update(item: Service) { this._list$.next(this._list$.value.map(s => s.id === item.id ? item : s)); }
  remove(id: number) { this._list$.next(this._list$.value.filter(s => s.id !== id)); }
}
